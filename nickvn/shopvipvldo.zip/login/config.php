<?
/*
#########################################################
#               Code Write By Duong IT 911              #
#              Email: svpv.hotro@gmail.com              #
#            Phone: 01693067818 - 01698330911           #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
$fb = new Facebook\Facebook ([
  'app_id' => '433639977324545', // Id app
  'app_secret' => '02a431b5c752cd4765d54cc7070934c5', // Mã bảo mật app
  'default_graph_version' => 'v3.0', //Giữ Nguyên
  ]);
$domain = 'https://shoplongsky.net/login/'; //Domain có / ở cuối
?>